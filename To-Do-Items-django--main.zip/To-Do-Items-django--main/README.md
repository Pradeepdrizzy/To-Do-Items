# TodoApp

## Registeration Page
![image](https://user-images.githubusercontent.com/93641901/166315897-a72bb2f7-fd2a-489d-ac34-d8cc13645072.png)


## Login Page
![image](https://user-images.githubusercontent.com/93641901/166315766-bdfbd4e6-99c6-479c-a097-1165ccd12251.png)


## To Do List
![image](https://user-images.githubusercontent.com/93641901/166316180-ef8c278d-31f1-42c3-9fdc-2369235957c9.png)



## Creating a task
![image](https://user-images.githubusercontent.com/93641901/166316036-035c62b1-584f-4e19-8598-1fdb8f67ebe3.png)



## Delete a task
![image](https://user-images.githubusercontent.com/93641901/166316244-d43fdabe-b522-4ecd-b708-01794dddb1a1.png)
